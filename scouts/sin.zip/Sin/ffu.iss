function main()
{
OgreBotAPI:AbilityTag_AddRotateTagTimer[${Me.Name}, FFU2Embargo, 25, Embargo]
OgreBotAPI:AbilityTag_ResetAbilityTagAllow[${Me.Name}, FFU1Allow]
OgreBotAPI:AbilityTag_ResetAbilityTagAllow[${Me.Name}, FFU2Allow]
    if ${OgreBotAPI.AbilityTag_GetTagEmbargoTimeRemaining["FFU1Embargo"]} < 25
    {
        OgreBotAPI:AbilityTag_AddRotateTagTimer[${Me.Name}, FFU1Embargo, 25, Embargo]
    }
}