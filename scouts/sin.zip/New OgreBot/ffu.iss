function main()
{
OgreBotAPI.CastStack:HoldTag[${Me.Name}, FFU2Embargo, 25, Embargo]
OgreBotAPI.CastStack:ClearAllow[${Me.Name}, FFU1Allow]
OgreBotAPI.CastStack:ClearAllow[${Me.Name}, FFU2Allow]
    if ${OgreBotAPI.CastStack.TagEmbargoRemaining["FFU1Embargo"]} < 25
    {
        OgreBotAPI.CastStack:HoldTag[${Me.Name}, FFU1Embargo, 25, Embargo]
    }
}