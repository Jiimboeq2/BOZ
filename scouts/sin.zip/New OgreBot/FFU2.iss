function main(string Args)
{
	echo ${Time} - ${Script.Filename} called.
    if !${Args.Length} == 0
	{
        echo ${Script.Filename} requires an argument.  The available options are ReadyUp, Mimic, and FFU.
    }
	
	if ${Args.Find[ReadyUp](exists)}
;When Called checks if Necrotic Blade is ready to determine if Ready Up proced on the Sin, and not someone else.
    {
			oc ${Me.Name} - ${Time} - Ready Up PROC
			echo ${Time} - Ready up PROC
			
			if (${Me.Ability[id,4115038578].TimeUntilReady}) <= 1
				{
				OgreBotAPI.CastStack:ClearAllEmbargos[${Me.Name}]
				Echo Reset ${Me.Name}
				}
		Echo Necrotic Refresh ${Me.Ability[id,4115038578].TimeUntilReady}
    }
	
    if ${Args.Find[Mimic](exists)}
; Mimic Calls for Enchanter to cast Mimic. Must have Mimic at top of Chanter stack with Allow tag of FFUMimic.
    {
		oc !ci -AbilityTag all FFUMimic 10 Allow -g ${Me.Name}
		oc ${Me.Name} - ${Time} - Mimic
    }
	
    if ${Args.Find[FFU](exists)}
    {
;When FFU Casts, this checks to make sure FFU1Allow does not trigger for at least 25 seconds to prevent it starting before FFU refreshes
		OgreBotAPI.CastStack:HoldTag[${Me.Name}, FFU2Embargo, 25, Embargo]
		OgreBotAPI.CastStack:ClearAllow[${Me.Name}, FFU1Allow]
		OgreBotAPI.CastStack:ClearAllow[${Me.Name}, FFU2Allow]
		if ${OgreBotAPI.CastStack.TagEmbargoRemaining["FFU1Embargo"]} < 25
			{
			OgreBotAPI.CastStack:HoldTag[${Me.Name}, FFU1Embargo, 25, Embargo]
			}
    }
    
}